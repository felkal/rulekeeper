const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Schedule = mongoose.model('schedules');
const Ticket = mongoose.model('tickets');


/* Endpoint GET /schedules */
router.get('/schedules', (req, res) => {
    Schedule.find({}, (err, schedules) => {
        if (err) { res.status(400).json('Error fetching schedules.'); return; }
        res.status(200).json(schedules);
      });
})


/* Endpoint POST /buy_ticket */
router.post('/buy_ticket', (req, res) => {
    const { name, e_mail, credit_card, destination, schedule } = req.body;

    if (!name || !e_mail || !credit_card || !destination || !schedule) {
      res.status(400).json('Missing information'); return;  }

    /* Create new ticket object */
    const ticket = { name: name, e_mail: e_mail, destination: destination, 
        date: Date.parse(schedule), credit_card: credit_card, };

    /* Add new ticket to database */
    Ticket.create(ticket,  (err, createdTicket ) => {
      if (err) { res.status(400).json('Error buying ticket.'); return; }

      /* Add new traveler to trip */
      Schedule.findOneAndUpdate({ destination: destination, date: schedule }, { $push: { travelers: name }}, {},
          (err, updatedSchedule) => {
              if (err) { res.status(400).json('Error adding traveler.'); return; }
              res.status(200).json({createdTicket, updatedSchedule });
          });
    });
})


/* Endpoint GET /purchase_history */
router.get('/purchase_history', (req, res) => {
    const { name } = req.query;

    Ticket.find( {$where: "this.name === '" + name + "'"} , 'name destination date -_id', (err, tickets) => {
      if (err) { res.status(400).json('Error fetching ticket history.'); return; }
      res.status(200).json(tickets);
    })
})


module.exports = router;
