const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Newsletter = mongoose.model('newsletter');


// Endpoint POST /subscribe
router.post('/subscribe', (req, res) => {
    const { e_mail } = req.body;
    if ( !e_mail) { res.status(400).json('Missing information'); return; }

    /* Create subscription e-mail object */
    const subscription = { e_mail: e_mail };

    /* Add new e-mail to newsletter database */
    Newsletter.create(subscription,  (err, subscribedEmail ) => {
      if (err) { res.status(400).json('Error subscribing to newsletter.'); return; }
      else res.status(200).json({ subscribedEmail });
    });
})

module.exports = router;
