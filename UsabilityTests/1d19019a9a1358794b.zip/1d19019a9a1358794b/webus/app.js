/* ************************************************************************ */
/*  App initialization                                                      */
/* ************************************************************************ */

const express = require('express');
const mongoose = require('mongoose');
require('./models/tickets')
require('./models/newsletter')
require('./models/schedules')
const tickets = mongoose.model('tickets');
const newsletters = mongoose.model('newsletter');
const schedules = mongoose.model('schedules');
const app = express();
const router = express.Router();

/* ************************************************************************ */
/*  Endpoints                                                               */
/* ************************************************************************ */


/* Endpoint corresponding to the subscribe to newsletter operation: POST /subscribe */
router.post('/subscribe', function(req,res) {
  const { e_mail } = req.body;
  if ( !e_mail) { res.status(400).json('Missing information'); return; }

  // Create new subscription object
  const subscription = { e_mail: e_mail };

  // Insert new email in the newsletters table
  newsletters.create(subscription,  (err, subscribedEmail ) => {
    if (err) { res.status(400).json('Error subscribing to newsletter.'); return; }
    else res.sendStatus(200);
  });
});

/* Endpoint corresponding to the get schedules operation: GET /schedules */
router.get('/schedules', function (req, res) {

  // Find all schedules in the schedule table
  schedules.find({}, (err, schedules) => {
    if (err) { res.status(400).json('Error fetching schedules.'); return; }
    res.status(200).json(schedules);
  });
});

/* Endpoint corresponding to the buy ticket operation: POST /buy_ticket */
router.post('/buy_ticket', function(req, res) {
  const { name, credit_card, destination, schedule } = req.body;

  // Create new ticket object
  const ticket = { name: name, destination: destination, 
    date: Date.parse(schedule), credit_card: credit_card };

  // Insert new ticket in the tickets table
  tickets.create(ticket,  (err) => {
    if (err) { res.sendStatus(400)}
    res.sendStatus(200);
  });
});

app.use(router)
module.exports = app;