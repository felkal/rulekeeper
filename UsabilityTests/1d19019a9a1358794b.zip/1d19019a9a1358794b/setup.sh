#!/bin/bash

USE_CASE=$1

# Run manifest parser
if [ $USE_CASE = "lab_v2" ]
then
    cp lab/gdpr_manifest.txt $USE_CASE/gdpr_manifest.txt
fi

# Generate graph
echo "[INFO] - Generating graph"
cd rulekeeper/js-cpg/parser
node parser.js ../../../$USE_CASE/app.js --csv


# Start container
echo "[INFO] - Starting container"
docker stop neo4j-rulekeeper > /dev/null
sudo service docker start
cd ../neo4j-custom
sudo ./run_full.sh &
