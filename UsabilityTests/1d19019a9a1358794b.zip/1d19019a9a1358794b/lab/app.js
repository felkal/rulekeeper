/* ************************************************************************ */
/*  App initialization                                                      */
/* ************************************************************************ */

const express = require('express');
const mongoose = require('mongoose');
require('./models/users');
require('./models/patients');
require('./models/newsletters');
const users = mongoose.model('users');
const patients = mongoose.model('patients');
const newsletters = mongoose.model('newsletters');
const app = express();
const router = express.Router();

/* ************************************************************************ */
/*  Endpoints                                                               */
/* ************************************************************************ */


/* Endpoint corresponding to the register user operation: POST /register_user */
router.post('/register_user',  function(req, res) {
  const { username, password, email } = req.body;
  if (!password || !username) { res.status(400).json('Missing username or password.'); return; }
  
  /* Generate hashed password */
  const salt = bcrypt.genSalt(10);
  const hashedPassword = bcrypt.hash(password, salt);

  /* Create new user object */
  const user = { username, password: hashedPassword, registration_date: Date.now(), e_mail: email };
  
  /* Insert new user in the users table */
  users.create(user, (err) => {
    if (err) { res.status(400).json('Error registering user.'); return; }
    else res.sendStatus(200);
  });  
});

/* Endpoint corresponding to the enroll patient operation: POST /enroll_patient */
router.post('/enroll_patient',  function(req, res) {
  const { citizencard, full_name, data } = req.body;
  if (!citizencard || !full_name || !data) { res.status(400).json('Missing information'); return; }

  /* Create new patient object */
  const patient = {
    citizencard: citizencard, patient_id: generateId(), full_name: full_name,
    birth_date: data.birth_date, gender: data.gender, ss_number: data.ss_number,
    photo: data.photo, address: data.address, mobile_number: data.mobile };

  /* Insert new patient in the patients table */
  patients.create(patient, (err) => {
    if (err) { res.status(400).json('Error enrolling patient'); return; }
    else res.status(200).json(patient);
  });    
});

/* Endpoint corresponding to the consult patient operation: GET /:patientId */
router.get('/:patientId',  function(req, res) {
  const { patientId } = req.params;
  
  /* Find patient data in the patients table */
  patients.findOne({ patientId: patientId }, (err, patient) => {
    if (err) { res.status(400).json('Error fetching patient data.'); return; }
    else res.status(200).json(patient);
  });
});

/* Endpoint corresponding to the update patient operation: POST /:patientId */
/* Update patient data. */
router.post('/:patientId',  function(req, res) {
  const { patientId } = req.params;
  const data = req.body; 

  /* Update patient data, if patient exists */
  patients.findOneAndUpdate({ patientId: patientId }, data, (updatedPatient, err) => {
    if (err) { res.status(400).json('Error updating patient data.'); return; }
    else res.status(200).json(updatedPatient);
  });
});

/* Endpoint corresponding to the subscribe to newsletter operation: POST /subscribe */
router.post('/subscribe', function(req,res) {
  const { e_mail } = req.body;
  if ( !e_mail) { res.status(400).json('Missing information'); return; }

  /* Create new subscription object */
  const subscription = { e_mail: e_mail };

  /* Insert new email in the users table */
  newsletters.create(subscription,  (err, subscribedEmail ) => {
    if (err) { res.status(400).json('Error subscribing to newsletter.'); return; }
        res.status(200).json(subscribedEmail);
  });
});

app.use(router)
module.exports = app;
