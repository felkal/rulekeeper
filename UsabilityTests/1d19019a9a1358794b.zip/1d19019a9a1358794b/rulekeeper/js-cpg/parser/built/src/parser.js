"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const yargs = require("yargs/yargs");
const fs = require("fs");
const esprima = require("esprima");
const escodegen_1 = __importDefault(require("escodegen"));
const normalizer_1 = require("./traverse/normalizer");
const { buildAST } = require("./traverse/ast_builder");
const { buildCFG } = require("./traverse/cfg_builder");
const { buildPDG } = require("./traverse/dep_builder");
const { OutputManager } = require("./output/output_strategy");
const { DotOutput } = require("./output/dot_output");
const { CSVOutput } = require("./output/csv_output");
const graph_1 = require("./traverse/graph/graph");
// Returns a graph object
function parse(filename) {
    try {
        const data = fs.readFileSync(filename, "utf8");
        const ast = esprima.parseScript(data);
        // const ast = esprima.parseScript(data, { loc: true });
        // printJSON(ast);
        // console.log("===============");
        const normalizedAst = (0, normalizer_1.normalizeScript)(ast);
        // printJSON(normalizedAst);
        // console.log("===============");
        const code = escodegen_1.default.generate(normalizedAst);
        console.log(code);
        // console.log("===============");
        const astGraph = buildAST(normalizedAst);
        const cfgGraph = buildCFG(astGraph);
        // return cfgGraph;
        const pdgGraph = buildPDG(cfgGraph);
        return pdgGraph;
    }
    catch (e) {
        console.log("Error:", e.stack);
    }
    return new graph_1.Graph(null);
}
const { argv } = yargs(process.argv.slice(3))
    .boolean("csv")
    .array("ignore")
    .boolean("show_code");
const filename = process.argv[2];
if (fs.existsSync(filename)) {
    const graphOptions = {
        ignore: argv.ignore || [],
        show_code: argv.show_code || false,
    };
    const graph = parse(filename);
    if (graph) {
        if (argv.csv) {
            graph.outputManager = new OutputManager(graphOptions, new CSVOutput());
        }
        else {
            graph.outputManager = new OutputManager(graphOptions, new DotOutput());
        }
        graph.output("src/graphs/graph");
    }
}
else {
    console.error(`${filename} is not a valid file.`);
}
//# sourceMappingURL=parser.js.map