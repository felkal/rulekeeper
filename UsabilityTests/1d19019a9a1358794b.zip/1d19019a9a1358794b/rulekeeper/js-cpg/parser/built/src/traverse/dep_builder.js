"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildPDG = void 0;
const utils_1 = require("../utils/utils");
;
function printAuxiliaryStructures(heap, store, phi) {
    console.log(heap);
    console.log(store);
    console.log(phi);
}
function handleExpressionStatement(node, oldHeap, oldStore, oldPhi) {
    const heap = (0, utils_1.clone)(oldHeap);
    const store = (0, utils_1.clone)(oldStore);
    const phi = (0, utils_1.clone)(oldPhi);
    return { heap, store, phi };
}
function buildPDG(cfgGraph) {
    const graph = cfgGraph;
    const startNodes = graph.startNodes.get("CFG");
    // Heap - Locations -> Objects
    let heap = new Map();
    // Store - Variable -> Locations
    let store = new Map();
    // Phi - Variable -> Statement Node Id
    let phi = new Map();
    const visitedNodes = [];
    function traverse(node) {
        if (node === null)
            return;
        // to avoid duplicate traversal of a node with more than one "from" CFG edge
        if (visitedNodes.includes(node.id))
            return;
        visitedNodes.push(node.id);
        console.log(node.id, node.type);
        switch (node.type) {
            case "ExpressionStatement": {
                ({ heap, store, phi } = handleExpressionStatement(node, heap, store, phi));
                break;
            }
            default:
                break;
        }
        node.edges
            .filter((edge) => edge.type === "CFG")
            .forEach((edge) => {
            const n = edge.nodes[1];
            traverse(n);
        });
    }
    startNodes === null || startNodes === void 0 ? void 0 : startNodes.forEach((node) => {
        traverse(node);
    });
    printAuxiliaryStructures(heap, store, phi);
    return graph;
}
exports.buildPDG = buildPDG;
//# sourceMappingURL=dep_builder.js.map