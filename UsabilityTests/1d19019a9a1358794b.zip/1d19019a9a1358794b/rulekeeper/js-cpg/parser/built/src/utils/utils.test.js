"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* eslint-disable no-undef */
const utils_1 = require("./utils");
test("create immutable copy of object", () => {
    const inputObj = {
        hello: "world",
    };
    expect((0, utils_1.copyObj)(inputObj)).toMatchObject(inputObj);
    expect((0, utils_1.copyObj)(inputObj)).not.toBe(inputObj);
});
test("reset node id", () => {
    (0, utils_1.getNextNodeId)();
    expect((0, utils_1.resetNodeId)()).toBe(1);
});
test("get next node id", () => {
    (0, utils_1.resetNodeId)();
    expect((0, utils_1.getNextNodeId)()).toBe(1);
    expect((0, utils_1.getNextNodeId)()).toBe(2);
    expect((0, utils_1.getNextNodeId)()).toBe(3);
    expect((0, utils_1.getNextNodeId)()).toBe(4);
});
test("reset variable count", () => {
    (0, utils_1.getNextVariableName)();
    expect((0, utils_1.resetVariableCount)()).toBe(1);
});
test("get variable name", () => {
    (0, utils_1.resetVariableCount)();
    expect((0, utils_1.getNextVariableName)()).toBe("v1");
    expect((0, utils_1.getNextVariableName)()).toBe("v2");
    expect((0, utils_1.getNextVariableName)()).toBe("v3");
    expect((0, utils_1.getNextVariableName)()).toBe("v4");
});
test("reset object count", () => {
    expect((0, utils_1.resetObjectCount)()).toBe(1);
});
test("get variable name", () => {
    (0, utils_1.resetObjectCount)();
    expect((0, utils_1.getNextObjectName)()).toBe("o1");
    expect((0, utils_1.getNextObjectName)()).toBe("o2");
    expect((0, utils_1.getNextObjectName)()).toBe("o3");
    expect((0, utils_1.getNextObjectName)()).toBe("o4");
});
//# sourceMappingURL=utils.test.js.map