"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normSequenceExpression = exports.normAwaitYieldExpression = exports.normMethodDefinition = exports.normClassBody = exports.normClassExpression = exports.normArrayExpression = exports.normProperty = exports.normObjectExpression = exports.normMemberExpression = exports.normCallExpression = exports.normArrowFunctionExpression = exports.normFunctionExpression = exports.normReturnStatement = exports.normFunctionDeclaration = exports.normUpdateExpression = exports.normExpressionStatement = exports.normAssignmentExpressions = exports.normWhileStatement = exports.normConditionalExpression = exports.normIfStatement = exports.normBlockStatement = exports.normVariableDeclarator = exports.normVariableDeclaration = exports.normBinaryExpression = exports.normProgram = exports.isNotEmpty = exports.isNotLiteral = exports.flatExprs = exports.flatStmts = exports.unpattern = exports.createPropertyAssignment = exports.createObjectLookupDeclarator = exports.createVariableDeclarator = exports.createVariableDeclaration = exports.createEmptyObject = exports.createIdentifierFromExpression = exports.createIdentifierWithName = exports.createRandomIdentifier = void 0;
const utils_1 = require("../utils/utils");
;
function createRandomIdentifier() {
    const variableName = (0, utils_1.getNextVariableName)();
    return {
        type: "Identifier",
        name: variableName,
    };
}
exports.createRandomIdentifier = createRandomIdentifier;
function createIdentifierWithName(name) {
    return {
        type: "Identifier",
        name,
    };
}
exports.createIdentifierWithName = createIdentifierWithName;
;
function createIdentifierFromExpression(expr) {
    switch (expr.type) {
        case "Identifier": {
            return expr;
        }
        case "Literal": {
            return createIdentifierWithName(expr === null || expr === void 0 ? void 0 : expr.value);
        }
    }
    return null;
}
exports.createIdentifierFromExpression = createIdentifierFromExpression;
function createEmptyObject() {
    return {
        type: "ObjectExpression",
        properties: [],
    };
}
exports.createEmptyObject = createEmptyObject;
;
;
;
function createVariableDeclaration(obj) {
    const id = createRandomIdentifier();
    const decl = {
        type: "VariableDeclaration",
        declarations: [
            {
                type: "VariableDeclarator",
                id,
                init: obj,
            },
        ],
        kind: "const",
    };
    return { id, decl };
}
exports.createVariableDeclaration = createVariableDeclaration;
;
function createVariableDeclarator(newInit) {
    const id = createRandomIdentifier();
    const decl = {
        type: "VariableDeclarator",
        id,
        init: newInit,
    };
    return { id, decl };
}
exports.createVariableDeclarator = createVariableDeclarator;
;
function createObjectLookupDeclarator(prop, objectValue) {
    const propValue = prop.value;
    const propKey = prop.key;
    const memExpr = {
        type: "MemberExpression",
        computed: false,
        optional: false,
        object: objectValue,
        property: propValue,
    };
    return {
        type: "VariableDeclarator",
        id: propKey,
        init: memExpr,
    };
}
exports.createObjectLookupDeclarator = createObjectLookupDeclarator;
;
function createPropertyAssignment(objId, propKey, propValue) {
    return {
        type: "ExpressionStatement",
        expression: {
            type: "AssignmentExpression",
            operator: "=",
            left: {
                type: "MemberExpression",
                computed: false,
                object: objId,
                property: propKey,
                optional: false,
            },
            right: propValue,
        },
    };
}
exports.createPropertyAssignment = createPropertyAssignment;
;
function unpattern(declarations) {
    const unpatternedDeclarations = [];
    declarations.forEach((d) => {
        if (d.id.type === "ObjectPattern") {
            const originalInit = d.init;
            const { id, decl } = createVariableDeclarator(originalInit);
            // push a new variable with the member expression
            unpatternedDeclarations.push(decl);
            // push declarations for each property using accesses to new variable
            d.id.properties.forEach((prop) => {
                if (prop.type === "Property")
                    unpatternedDeclarations.push(createObjectLookupDeclarator(prop, id));
            });
        }
        else {
            unpatternedDeclarations.push(d);
        }
    });
    return unpatternedDeclarations;
}
exports.unpattern = unpattern;
;
const flatStmts = (children) => children.map((child) => child.stmts).flat();
exports.flatStmts = flatStmts;
const flatExprs = (children) => children.map((child) => child.expr).flat();
exports.flatExprs = flatExprs;
const isNotLiteral = (obj) => obj.type !== "Literal" && obj.type !== "Identifier";
exports.isNotLiteral = isNotLiteral;
function isNotEmpty(obj) {
    if (obj.type === "ArrayExpression") {
        return obj.elements.length > 0;
    }
    return true;
}
exports.isNotEmpty = isNotEmpty;
;
function normProgram(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.body = (0, exports.flatStmts)(children);
    return { stmts: [newObj], expr: null };
}
exports.normProgram = normProgram;
;
function normBinaryExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const leftExpr = children[0].expr;
    const rightExpr = children[1].expr;
    // if both left and right expression were not normalized we just ignore
    if (leftExpr && rightExpr) {
        newObj.left = children[0].expr;
        newObj.right = children[1].expr;
        const { id, decl } = createVariableDeclaration(newObj);
        return {
            stmts: [...children[0].stmts, ...children[1].stmts, decl],
            expr: id,
        };
    }
    return { stmts: [], expr: newObj };
}
exports.normBinaryExpression = normBinaryExpression;
;
function normVariableDeclaration(obj, children) {
    const childStmts = (0, exports.flatStmts)(children);
    // remove expr === null which happens in some cases when
    // the declarator has no expression due to normalization
    const newStmts = (0, exports.flatExprs)(children)
        .filter((expr) => expr !== null)
        .map((expr) => {
        const newObj = (0, utils_1.copyObj)(obj);
        newObj.declarations = [expr];
        return newObj;
    });
    return {
        stmts: [...childStmts, ...newStmts],
        expr: null,
    };
}
exports.normVariableDeclaration = normVariableDeclaration;
;
function normVariableDeclarator(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    let stmts = [];
    // children 0 is identifier
    // newObj.id = children[0].expr;
    // children 1 is init
    const newInit = children[1];
    if (newInit) {
        if (newInit.expr && newInit.expr.type === "ObjectExpression") {
            const objExpr = newInit.expr;
            // push empty object for this identifier
            newObj.init = createEmptyObject();
            const newAssignments = [];
            // push declarations for each property using accesses to new variable
            objExpr.properties.forEach((prop) => {
                if (prop.type === "Property") {
                    const propKey = createIdentifierFromExpression(prop.key);
                    const propValue = prop.value;
                    if (propKey && propValue)
                        newAssignments.push(createPropertyAssignment(newObj.id, propKey, propValue));
                }
            });
            const newDecl = (0, utils_1.copyObj)(parent);
            newDecl.declarations = [newObj];
            stmts = [...newInit.stmts, newDecl, ...newAssignments];
            return {
                stmts,
                expr: null,
            };
        }
        // all other init types
        stmts = [...newInit.stmts];
        const newInitExpression = newInit.expr;
        newObj.init = newInitExpression;
    }
    return {
        stmts,
        expr: newObj,
    };
}
exports.normVariableDeclarator = normVariableDeclarator;
;
function normBlockStatement(obj, children) {
    const stmts = (0, exports.flatStmts)(children);
    // shouldn't really be anything here
    const exprs = (0, exports.flatExprs)(children).filter((elem) => elem != null);
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.body = [...stmts, ...exprs];
    return {
        stmts: [newObj],
        expr: null,
    };
}
exports.normBlockStatement = normBlockStatement;
;
function normIfStatement(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.test = children[0].expr;
    [newObj.consequent] = children[1].stmts;
    if (newObj.alternate) {
        [newObj.alternate] = children[2].stmts;
    }
    return {
        stmts: [...children[0].stmts, newObj],
        expr: null,
    };
}
exports.normIfStatement = normIfStatement;
;
function normConditionalExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.test = children[0].expr;
    newObj.consequent = children[1].expr;
    newObj.alternate = children[2].expr;
    return {
        stmts: [...children[0].stmts, ...children[1].stmts, ...children[2].stmts],
        expr: newObj,
    };
}
exports.normConditionalExpression = normConditionalExpression;
;
function normWhileStatement(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.test = children[0].expr;
    [newObj.body] = children[1].stmts;
    return {
        stmts: [...children[0].stmts, newObj],
        expr: null,
    };
}
exports.normWhileStatement = normWhileStatement;
;
function normAssignmentExpressions(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    const leftExpr = children[0].expr;
    const rightExpr = children[1].expr;
    // if both left and right expression were not normalized we just ignore
    if (leftExpr && rightExpr) {
        newObj.left = leftExpr;
        if (rightExpr.type === "ObjectExpression") {
            // push empty object for this identifier
            newObj.right = createEmptyObject();
            const newAssignments = [];
            // push declarations for each property using accesses to new variable
            rightExpr.properties.forEach((prop) => {
                if (prop.type === "Property") {
                    const propKey = createIdentifierFromExpression(prop.key);
                    const propValue = prop.value;
                    if (propKey && propValue)
                        newAssignments.push(createPropertyAssignment(newObj.left, propKey, propValue));
                }
            });
            const newExprStmt = (0, utils_1.copyObj)(parent);
            newExprStmt.expression = newObj;
            return {
                stmts: [...children[1].stmts, newExprStmt, ...newAssignments],
                expr: null,
            };
        }
        newObj.right = rightExpr;
        return {
            stmts: [...children[0].stmts, ...children[1].stmts],
            expr: newObj,
        };
    }
    return { stmts: [], expr: newObj };
}
exports.normAssignmentExpressions = normAssignmentExpressions;
;
function normExpressionStatement(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const expression = children[0].expr;
    // if the expression was not normalization we just ignore
    if (expression) {
        newObj.expression = expression;
        return {
            stmts: [...children[0].stmts, newObj],
            expr: null,
        };
    }
    return {
        stmts: [...(0, exports.flatStmts)(children)],
        expr: null,
    };
}
exports.normExpressionStatement = normExpressionStatement;
;
function normUpdateExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const argument = children[0].expr;
    // if the argument was not normalization we just ignore
    if (argument) {
        newObj.argument = argument;
        const { id, decl } = createVariableDeclaration(newObj);
        return {
            stmts: [...children[0].stmts, decl],
            expr: id,
        };
    }
    return { stmts: [], expr: newObj };
}
exports.normUpdateExpression = normUpdateExpression;
;
function normFunctionDeclaration(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const funcId = children[0];
    const funcBody = children[1];
    if (funcId) {
        newObj.id = funcId.expr;
    }
    [newObj.body] = funcBody.stmts;
    return {
        stmts: [newObj],
        expr: null,
    };
}
exports.normFunctionDeclaration = normFunctionDeclaration;
;
function normReturnStatement(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    // check if there are any arguments
    if (children[0]) {
        newObj.argument = children[0].expr;
        return {
            stmts: [...children[0].stmts, newObj],
            expr: null,
        };
    }
    return {
        stmts: [newObj],
        expr: null,
    };
}
exports.normReturnStatement = normReturnStatement;
;
function normFunctionExpression(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    let stmts = [];
    if (children[0]) {
        newObj.id = children[0].expr;
    }
    [newObj.body] = children[1].stmts;
    if (parent
        && (parent.type === "VariableDeclarator"
            || parent.type === "ExpressionStatement"
            || parent.type === "AssignmentExpression"
            || parent.type === "MethodDefinition")) {
        return {
            stmts: [],
            expr: newObj,
        };
    }
    const { id, decl } = createVariableDeclaration(newObj);
    stmts.push(decl);
    return {
        stmts,
        expr: id,
    };
}
exports.normFunctionExpression = normFunctionExpression;
;
function normArrowFunctionExpression(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    let stmts = [];
    if (children[0].expr) { // body is an expression
        newObj.body = children[0].expr;
        stmts = children[0].stmts;
    }
    else { // body is a block statement
        [newObj.body] = children[0].stmts;
    }
    if (parent
        && (parent.type === "VariableDeclarator"
            || parent.type === "ExpressionStatement"
            || parent.type === "AssignmentExpression")) {
        return {
            stmts,
            expr: newObj,
        };
    }
    const { id, decl } = createVariableDeclaration(newObj);
    stmts.push(decl);
    return {
        stmts,
        expr: id,
    };
}
exports.normArrowFunctionExpression = normArrowFunctionExpression;
;
// IDEA: change it to a while??
// function normForStatement(obj, children, parent) {
//     const stmts = children[0].stmts.concat(children[2].stmts);
//     const newObj = copyObj(obj);
//     newObj.init = children[0].expr;
//     //newObj.test = children[1].expr;
//     newObj.update = children[2].expr;
//     newObj.body = children[3].stmts[0];
//     return {
//         stmts: stmts.concat(newObj),
//         expr: null,
//     };
// }
function normCallExpression(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.callee = children[0].expr;
    newObj.arguments = (0, exports.flatExprs)(children.slice(1));
    if (parent
        && (parent.type === "VariableDeclarator"
            || parent.type === "ExpressionStatement"
            || parent.type === "AssignmentExpression"
            || parent.type === "AwaitExpression")) {
        return {
            stmts: [...(0, exports.flatStmts)(children)],
            expr: newObj,
        };
    }
    const { id, decl } = createVariableDeclaration(newObj);
    return {
        stmts: [...(0, exports.flatStmts)(children), decl],
        expr: id,
    };
}
exports.normCallExpression = normCallExpression;
;
function normMemberExpression(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.object = children[0].expr;
    newObj.property = children[1].expr;
    if (parent
        && (parent.type === "VariableDeclarator"
            || parent.type === "ExpressionStatement"
            || parent.type === "AssignmentExpression")) {
        return {
            stmts: [...children[0].stmts, ...children[1].stmts],
            expr: newObj,
        };
    }
    const { id, decl } = createVariableDeclaration(newObj);
    return {
        stmts: [...children[0].stmts, ...children[1].stmts, decl],
        expr: id,
    };
}
exports.normMemberExpression = normMemberExpression;
function normObjectExpression(obj, children, parent) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.properties = [...(0, exports.flatExprs)(children)];
    if (parent
        && (parent.type === "VariableDeclarator"
            || parent.type === "ExpressionStatement"
            || parent.type === "AssignmentExpression")) {
        return {
            stmts: [...(0, exports.flatStmts)(children)],
            expr: newObj,
        };
    }
    const { id, decl } = createVariableDeclaration(newObj);
    return {
        stmts: [...(0, exports.flatStmts)(children), decl],
        expr: id,
    };
}
exports.normObjectExpression = normObjectExpression;
;
function normProperty(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const normalizedKey = children[0];
    const normalizedValue = children[1];
    const keyStmts = [...normalizedKey.stmts];
    const valueStmts = [...normalizedValue.stmts];
    const keyExpr = normalizedKey.expr;
    if (keyExpr && (0, exports.isNotLiteral)(keyExpr)) {
        const { id, decl } = createVariableDeclaration(keyExpr);
        newObj.key = id;
        keyStmts.push(decl);
    }
    else {
        newObj.key = keyExpr;
    }
    const valueExpr = normalizedValue.expr;
    if (valueExpr && (0, exports.isNotLiteral)(valueExpr) && isNotEmpty(valueExpr)) {
        const { id, decl } = createVariableDeclaration(valueExpr);
        newObj.value = id;
        valueStmts.push(decl);
    }
    else {
        newObj.value = valueExpr;
    }
    return {
        stmts: [...keyStmts, ...valueStmts],
        expr: newObj,
    };
}
exports.normProperty = normProperty;
function normArrayExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.elements = [...(0, exports.flatExprs)(children)];
    return {
        stmts: [...(0, exports.flatStmts)(children)],
        expr: newObj,
    };
}
exports.normArrayExpression = normArrayExpression;
function normClassExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const classBodyNormalization = children[2];
    if (classBodyNormalization.expr) {
        newObj.body = classBodyNormalization.expr;
    }
    return {
        stmts: [],
        expr: newObj,
    };
}
exports.normClassExpression = normClassExpression;
function normClassBody(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.body = [...(0, exports.flatExprs)(children)];
    return {
        stmts: [],
        expr: newObj,
    };
}
exports.normClassBody = normClassBody;
function normMethodDefinition(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const [keyNormalization, valueNormalization] = children;
    if (keyNormalization.expr) {
        newObj.key = keyNormalization.expr;
    }
    if (valueNormalization.expr) {
        newObj.value = valueNormalization.expr;
    }
    return {
        stmts: [],
        expr: newObj,
    };
}
exports.normMethodDefinition = normMethodDefinition;
function normAwaitYieldExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    const [argumentNormalization] = children;
    if (argumentNormalization.expr) {
        newObj.argument = argumentNormalization.expr;
    }
    return {
        stmts: [...(0, exports.flatStmts)(children)],
        expr: newObj,
    };
}
exports.normAwaitYieldExpression = normAwaitYieldExpression;
function normSequenceExpression(obj, children) {
    const newObj = (0, utils_1.copyObj)(obj);
    newObj.expressions = [...(0, exports.flatExprs)(children)];
    return {
        stmts: [...(0, exports.flatStmts)(children)],
        expr: newObj,
    };
}
exports.normSequenceExpression = normSequenceExpression;
//# sourceMappingURL=normalizerUtils.js.map
