from re import S
from neo4j import GraphDatabase
from typing import Dict, Any
import hashlib
import json
import datetime

## RETURN
# CallExpression
def find_function_calls(session, functionName):
	functionCalls = []
	with session.begin_transaction() as tx:
		# QUERY 1
		# get CallExpression that holds the call to a functionName
		query = f"""
            MATCH
                (c:CallExpression)-[callee:AST]->(i:Identifier)
            WHERE
                i.IdentifierName = "{functionName}" AND
                callee.RelationType = "callee"
			RETURN *
		"""
		queryResults = tx.run(query)
		for record in queryResults:
			functionCalls.append(record['c'])
	return functionCalls


def find_pdg_object(session, variableId):
    results = []
    with session.begin_transaction() as tx:
            # QUERY 2
            # get PDGObject resulting from the require a package
        query = f"""
                MATCH (v)-[c:OBJECT]->(o:PDG_OBJECT)
                WHERE v.Id="{variableId}" AND c.RelationType="CREATE"
                RETURN *
            """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append(record["o"])
    return results


## RETURN
# {
#     variable: variableDeclarator,
#     object: PDF_OBJECT
# }
def find_require_calls(session, packageName):
    requireCalls = find_function_calls(session, "require")

    variablesHoldingPackages = []
    for call in requireCalls:
        callId = call.id
        with session.begin_transaction() as tx:
            # QUERY 3
            # get VariableDeclarator that holds the call to a functionName
            query = f"""
                MATCH
                    (v:VariableDeclarator)-[:AST]->(c:CallExpression)-[r:AST]->(l:Literal)
                WHERE
                    c.Id = "{callId}" AND
                    r.RelationType = "arg" AND
                    r.ArgumentIndex = "1" AND
                    l.Value = "{packageName}"
                RETURN *
            """
            queryResults = tx.run(query)
            for record in queryResults:
                variablesHoldingPackages.append(record['v'])

    packageObject = {}
    for variable in variablesHoldingPackages:
        variableId = variable.id
        pdgObject = find_pdg_object(session, variableId)[0]
        packageObject = {
            "variable": variable,
            "object": pdgObject
        }
    return packageObject


def find_lookup_property(session, objectId, propertyName):
    lookupVariables = []
    with session.begin_transaction() as tx:
        # QUERY 4
        # get variables holding the model function
        query = f"""
            MATCH
                (o:PDG_OBJECT)-[dep:PDG]->(v:VariableDeclarator)
            WHERE
                o.Id="{objectId}" AND
                dep.RelationType="LOOKUP" AND
                dep.IdentifierName="{propertyName}"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            lookupVariables.append(record["v"])

    return lookupVariables


def find_call_with_no_param(session, fundDeclId, funcCallName):
    results = []
    with session.begin_transaction() as tx:
        # QUERY 5
        # get call to the router function
        query = f"""
            MATCH
                (v)-[dep:PDG]->(stmt)-[:AST]->(c:CallExpression)-[callee:AST]->(i:Identifier)
            WHERE
                v.Id="{fundDeclId}" AND
                dep.RelationType="VAR" AND
                dep.IdentifierName="{funcCallName}" AND
                callee.RelationType="callee" AND
                i.IdentifierName="{funcCallName}"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append(record["stmt"])
    return results


def find_calls_with_one_param(session, fundDeclId, funcCallName):
    results = []
    with session.begin_transaction() as tx:
        # QUERY 6
        # get calls to the mongoose model function
        query = f"""
            MATCH
                (v1)-[dep:PDG]->(stmt)-[:AST]->(c:CallExpression)-[callee:AST]->(i:Identifier),
                (c)-[arg:AST]->(l:Literal)
            WHERE
                v1.Id="{fundDeclId}" AND
                dep.RelationType="VAR" AND
                dep.IdentifierName="{funcCallName}" AND
                callee.RelationType="callee" AND
                i.IdentifierName="{funcCallName}" AND
                arg.RelationType="arg" AND
                arg.ArgumentIndex="1"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "stmt": record["stmt"], # could be VariableDeclarator or ExpressionsStatement
                "param_value": record["l"]["Value"]
            })
    return results

# def find_require_models(session):
#     requireCalls = find_function_calls(session, "require")

#     modelVariables = []
#     for call in requireCalls:
#         callId = call.id
#         with session.begin_transaction() as tx:
#             # QUERY 3
#             # get VariableDeclarator that holds the call to a functionName
#             query = f"""
#                 MATCH
#                     (v:VariableDeclarator)-[:AST]->(c:CallExpression)-[r:AST]->(l:Literal)
#                 WHERE
#                     c.Id = "{callId}" AND
#                     r.RelationType = "arg" AND
#                     r.ArgumentIndex = "1" AND
#                     l.Value =~ "(?i).*MODEL.*"
#                 RETURN *
#             """
#             queryResults = tx.run(query)
#             for record in queryResults:
#                 modelVariables.append(record['v'])

#     return modelVariables


def find_mongoose_model_calls(session, mongooseObject):
    mongooseObjectId = mongooseObject["object"].id
    modelFunctionVariable = find_lookup_property(session, mongooseObjectId, "model")

    models = []
    # for cases such as m = mongoose.model("m")
    if len(modelFunctionVariable) > 0:
        for modelFunction in modelFunctionVariable:
            modelFunctionId = modelFunction.id
            modelFunctionName = modelFunction["IdentifierName"]
            for model in find_calls_with_one_param(session, modelFunctionId, modelFunctionName):
                models.append(model)

    # # for cases such as m = require("model/m")
    # for model in find_require_models(session):
    #             models.append(model)

    return models


def find_express_router_methods(session, expressObject):
    expressObjectId = expressObject["object"].id
    routerFunctions = find_lookup_property(session, expressObjectId, "Router")
    routerCall = None
    methods = []

    for routerFunction in routerFunctions:
        routerFunctionId = routerFunction.id
        routerFunctionName = routerFunction["IdentifierName"]
        routerCalls = find_call_with_no_param(session, routerFunctionId, routerFunctionName)

        for routerCall in routerCalls:
            routerCallId = routerCall.id
            routerObject = find_pdg_object(session, routerCallId)[0]
            if routerObject:
                routerObjectId = routerObject.id

                postFunctions = find_lookup_property(session, routerObjectId, "post")
                for post in postFunctions:
                    postFunctionId = post.id
                    postFunctionName = post["IdentifierName"]
                    postCall = find_calls_with_one_param(session, postFunctionId, postFunctionName)[0]
                    postCallback = find_methods_callback(session, postCall["stmt"].id)[0]
                    methods.append({
                        "endpoint_type": "POST",
                        "endpoint": postCall,
                        "callback": postCallback
                    })

                getFunctions = find_lookup_property(session, routerObjectId, "get")
                for get in getFunctions:
                    getFunctionId = get.id
                    getFunctionName = get["IdentifierName"]
                    getCall = find_calls_with_one_param(session, getFunctionId, getFunctionName)[0]
                    getCallback = find_methods_callback(session, getCall["stmt"].id)[0]
                    methods.append({
                        "endpoint_type": "GET",
                        "endpoint": getCall,
                        "callback": getCallback
                    })

                putFunctions = find_lookup_property(session, routerObjectId, "put")
                for put in putFunctions:
                    putFunctionId = put.id
                    putFunctionName = put["IdentifierName"]
                    putCall = find_calls_with_one_param(session, putFunctionId, putFunctionName)[0]
                    putCallback = find_methods_callback(session, putCall["stmt"].id)[0]
                    methods.append({
                        "endpoint_type": "PUT",
                        "endpoint": putCall,
                        "callback": putCallback
                    })

                deleteFunctions = find_lookup_property(session, routerObjectId, "delete")
                for delete in deleteFunctions:
                    deleteFunctionId = delete.id
                    deleteFunctionName = delete["IdentifierName"]
                    deleteCall = find_calls_with_one_param(session, deleteFunctionId, deleteFunctionName)[0]
                    deleteCallback = find_methods_callback(session, deleteCall["stmt"].id)[0]
                    methods.append({
                        "endpoint_type": "DELETE",
                        "endpoint": deleteCall,
                        "callback": deleteCallback
                    })

                paramFunctions = find_lookup_property(session, routerObjectId, "param")
                for param in paramFunctions:
                    paramFunctionId = param.id
                    paramFunctionName = param["IdentifierName"]
                    paramCall = find_calls_with_one_param(session, paramFunctionId, paramFunctionName)[0]
                    paramCallback = find_methods_callback(session, paramCall["stmt"].id)[0]
                    methods.append({
                        "endpoint_type": "PARAM",
                        "endpoint": paramCall,
                        "callback": paramCallback
                    })

    return methods

def find_callback_arg_number(session, callStmtId):
    with session.begin_transaction() as tx:
        # QUERY 7
        # get callback decl stmt and function node
        query = f"""
            MATCH
                (e)-[:AST]->(c:CallExpression)-[arg:AST]->(i)
            WHERE
                e.Id="{callStmtId}" AND
                arg.RelationType="arg"
            RETURN count(arg) as argNum
        """
        queryResults = tx.run(query)
        for record in queryResults:
            return record["argNum"]


def find_function_arg_number(session, callExpressionId):
    with session.begin_transaction() as tx:
        # QUERY 7
        # get callback decl stmt and function node
        query = f"""
            MATCH
                (c:CallExpression)-[arg:AST]->(i)
            WHERE
                c.Id="{callExpressionId}" AND
                arg.RelationType="arg"
            RETURN count(arg) as argNum
        """
        queryResults = tx.run(query)
        for record in queryResults:
            return record["argNum"]


def find_new_arg_number(session, newExpressionId):
    with session.begin_transaction() as tx:
        # QUERY 7
        # get callback decl stmt and function node
        query = f"""
            MATCH
                (n:NewExpression)-[arg:AST]->(i)
            WHERE
                n.Id="{newExpressionId}" AND
                arg.RelationType="arg"
            RETURN count(arg) as argNum
        """
        queryResults = tx.run(query)
        for record in queryResults:
            return record["argNum"]


def find_methods_callback(session, callStmtId):
    results = []
    numArgs = find_callback_arg_number(session, callStmtId)
    if numArgs == None:
        numArgs = 2

    with session.begin_transaction() as tx:
        # QUERY 7
        # get callback decl stmt and function node
        query = f"""
            MATCH
                (e)-[:AST]->(c:CallExpression)-[arg:AST]->(i:Identifier),
                (v:VariableDeclarator)-[dep:PDG]->(e),
                (v)-[init:AST]->(f)
            WHERE
                e.Id="{callStmtId}" AND
                arg.RelationType="arg" AND
                arg.ArgumentIndex="{numArgs}" AND
                dep.RelationType="VAR" AND
                dep.IdentifierName=i.IdentifierName AND
                init.RelationType="init"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "callback_decl": record["v"],
                "callback_func": record["f"]
            })

    return results


def getOperationIndex(operation):
    return {
        "create": "1",
        #"find": "1",
        "findOne": "1",
        # "findOneAndUpdate": "2",
        "deleteOne": "1",
        "updateMany": "2",
        # "findById": "1",
    }.get(operation)


def getOperationType(operation):
    return {
        "create": "PARAM",
        "find": "PARAM",
        "findOne": "PARAM",
        "findOneAndUpdate": "PARAM",
        "deleteOne": "PARAM",
        "updateMany": "PARAM",
        "findById": "SELECT",
        "save": "OBJECT",
        "remove": "OBJECT",
    }.get(operation)

# def getOperationType(operation):
#     return {
#         "create": "PARAM",
#         "find": "SELECT",
#         "findOne": "SELECT",
#         "findOneAndUpdate": "SELECT",
#         "deleteOne": "PARAM",
#         "updateMany": "PARAM",
#         "findById": "SELECT",
#         "save": "OBJECT",
#         "remove": "OBJECT",
#     }.get(operation)

returnAllOperations = ["findById", "find", "findOne", "findOneAndUpdate"]

DIRECT_API_CALLS = '["create", "findOne", "find", "findOneAndUpdate", "deleteOne", "updateMany"]'

def find_direct_model_calls(session, modelStmtId):
    results = []
    with session.begin_transaction() as tx:
        # QUERY 8
        # get model.create stmt
        query = f"""
            WITH {DIRECT_API_CALLS} as APICalls
            MATCH
                (t)-[create:OBJECT]->(o:PDG_OBJECT)-[lookup:PDG]->(stmt)-[var:PDG]->(expression)-[e:AST]->(call:CallExpression)-[callee:AST]->(i:Identifier)
            WHERE
                t.Id="{modelStmtId}" AND
                create.RelationType="CREATE" AND
                lookup.RelationType="LOOKUP" AND
                lookup.IdentifierName in APICalls AND
                var.IdentifierName=stmt.IdentifierName AND
                (e.RelationType="expression" OR e.RelationType="init") AND
                callee.RelationType="callee" AND
                i.IdentifierName=stmt.IdentifierName
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "model_object": record["o"],
                "create_stmt": record["stmt"],
                "expression_stmt": record["expression"],
                "call": record["call"],
                "op": record["lookup"]["IdentifierName"]
            })
    return results


INDIRECT_API_CALLS = '["findById"]'

def find_indirect_model_calls(session, modelStmtId):
    results = []
    with session.begin_transaction() as tx:
        # QUERY 8
        # get model.create stmt
        query = f"""
            WITH {INDIRECT_API_CALLS} as APICalls
            MATCH
                (t)-[create:OBJECT]->(o:PDG_OBJECT)-[lookup:PDG]->(v:VariableDeclarator)-[init:AST]->(m:MemberExpression)-[property:AST]->(p),
                (v)-[var:PDG]->(vCall)-[e:AST]->(call:CallExpression)
            WHERE
                t.Id="{modelStmtId}" AND
                init.RelationType="init" AND
                lookup.RelationType="LOOKUP" AND
                lookup.IdentifierName in APICalls AND
                property.RelationType="property" AND
                p.IdentifierName=lookup.IdentifierName AND
                var.IdentifierName=v.IdentifierName AND
                (e.RelationType="expression" OR e.RelationType="init")
            RETURN *
        """

        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "model_object": record["t"],
                "create_stmt": record["v"],
                "expression_stmt": record["vCall"],
                "call": record["call"],
                "op": record["lookup"]["IdentifierName"]
            })
    return results


INDIRECT_API_NEW_CALLS = '["save", "remove"]'

def find_indirect_model_new_calls(session, modelStmtId):
    results = []
    with session.begin_transaction() as tx:
        # QUERY 8
        # get model.create stmt
        query = f"""
            WITH {INDIRECT_API_NEW_CALLS} as APICalls
            MATCH
                (t)-[:PDG]->(v:VariableDeclarator)-[init:AST]->(n:NewExpression),
                (v)-[create:OBJECT]->(o:PDG_OBJECT)-[lookup:PDG]->(vFunc)-[var:PDG]->(vCall)-[e:AST]->(call:CallExpression)
            WHERE
                t.Id="{modelStmtId}" AND
                init.RelationType="init" AND
                create.RelationType="CREATE" AND
                lookup.RelationType="LOOKUP" AND
                lookup.IdentifierName in APICalls AND
                var.IdentifierName=vFunc.IdentifierName AND
                (e.RelationType="expression" OR e.RelationType="init")
            RETURN *
        """

        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "model_object": record["t"],
                "create_stmt": record["vFunc"],
                "expression_stmt": record["vCall"],
                "call": record["call"],
                "op": record["lookup"]["IdentifierName"]
            })
    return results


def find_model_api_calls(session, model):
    modelStmtId = model["stmt"].id
    # print(modelStmtId)
    directCalls = find_direct_model_calls(session, modelStmtId)
    indirectCalls = find_indirect_model_calls(session, modelStmtId)
    indirectNewCalls = find_indirect_model_new_calls(session, modelStmtId)
    return directCalls + indirectCalls + indirectNewCalls


def get_functions_in_function_scope(session, functionDecl):
    results = []
    functionName = functionDecl["IdentifierName"]
    with session.begin_transaction() as tx:
        query= f"""
            MATCH
                (f:CFG_F_START)-[:CFG*1..]->(v)-[init:AST]->(fd)
            WHERE
                f.IdentifierName="{functionName}" AND
                (fd.Type="FunctionExpression" OR fd.Type="ArrowFunctionExpression") AND
                init.RelationType="init"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "function_stmt": record["v"],
                "function_decl": record["fd"]
            })

    return results


def in_function_scope(session, functionDecl, stmtWithCall):
    functionName = functionDecl["IdentifierName"]
    stmtWithCallId = stmtWithCall.id

    # print(functionName, stmtWithCallId)

    with session.begin_transaction() as tx:
        # QUERY 9
        # get (function, parameter) pairs that we consider source
        query = f"""
            MATCH
                (f:CFG_F_START)-[:CFG*1..]->(expression)
            WHERE
                f.IdentifierName="{functionName}" AND
                expression.Id="{stmtWithCallId}"
            RETURN *
        """
        queryResults = tx.run(query)

        if queryResults.peek():
            return True

    return False


def is_call_in_function_scope(session, functionDecl, stmtWithCall):
    result = False

    subFunctions = get_functions_in_function_scope(session, functionDecl)
    # print("No. subfunctions: ", len(subFunctions))

    # handle stmts directly in this function scope
    result = result or in_function_scope(session, functionDecl, stmtWithCall)

    # check if the call is in any functions declared inside this function
    for sf in subFunctions:
        subFunctionDecl = sf["function_decl"]
        result = result or is_call_in_function_scope(session, subFunctionDecl, stmtWithCall)

    return result


def get_new_expression(session, modelStmtId, callExpressionId):
    with session.begin_transaction() as tx:
            # QUERY 11
            # get object used as first param for model.create call
            query=f"""
                MATCH
                    (m)-[:PDG]->(v:VariableDeclarator)-[init:AST]->(n:NewExpression)-[callee:AST]->(i:Identifier),
                    (v)-[:CFG*1..]->(v2:VariableDeclarator)-[:AST]->(c:CallExpression)
                WHERE
                    m.Id="{modelStmtId}" AND
                    c.Id="{callExpressionId}" AND
                    init.RelationType="init" AND
                    callee.RelationType="callee" AND
                    m.IdentifierName=i.IdentifierName
                RETURN *
            """
            queryResults = tx.run(query)
            for record in queryResults:
                return {
                    "new_expression": record["n"],
                    "new_stmt": record["v"]
                }


def find_api_param(session, modelAPICall):
    results = []

    modelOperation = modelAPICall["op"]
    callExpression = modelAPICall["call"]
    callExpressionId = callExpression.id
    # print(callExpressionId)

    operationType = getOperationType(modelOperation)
    if operationType == "PARAM":
        argumentIndex = getOperationIndex(modelOperation)
        # print(argumentIndex)

        # Get number of arguments
        argNum = find_function_arg_number(session, callExpressionId)
        # print("ArgNum: ", argNum)

        if (not argumentIndex) or (argNum == 0):
            # When the param does not exist in the call (ex. find())
            with session.begin_transaction() as tx:
                query=f"""
                        MATCH
                            (v)-[var:PDG]->(e)-[expression:AST]->(c:CallExpression)-[callee:AST]->(i:Identifier)
                        WHERE
                            c.Id="{callExpressionId}" AND
                            (expression.RelationType="expression" OR expression.RelationType="init") AND
                            var.RelationType="VAR" AND
                            callee.RelationType="callee" AND
                            v.IdentifierName=i.IdentifierName
                        RETURN *
                    """
                queryResults = tx.run(query)
                for record in queryResults:
                    results.append({
                        "stmt": record["v"],
                        "variable_name": record["v"]["IdentifierName"]
                    })
        else:
            # When the param exists in the call
            # print(callExpressionId)
            with session.begin_transaction() as tx:
                # QUERY 10
                # get object used as first param for model.create call
                query=f"""
                    MATCH
                        (v)-[var:PDG]->(e)-[expression:AST]->(c:CallExpression)-[arg:AST]->(i:Identifier)
                    WHERE
                        (expression.RelationType="expression" OR expression.RelationType="init") AND
                        c.Id="{callExpressionId}" AND
                        arg.RelationType="arg" AND
                        arg.ArgumentIndex="{argumentIndex}" AND
                        var.RelationType="VAR" AND
                        var.IdentifierName=i.IdentifierName
                    RETURN *
                """
                queryResults = tx.run(query)
                for record in queryResults:
                    results.append({
                        "stmt": record["v"],
                        "variable_name": record["i"]["IdentifierName"]
                    })

    elif operationType == "OBJECT":
        modelStmtId = modelAPICall["model_object"].id

        newExpression = get_new_expression(session, modelStmtId, callExpressionId)
        newExpressionId = newExpression["new_expression"].id
        newStmtId = newExpression["new_stmt"].id

        newArgs = find_new_arg_number(session, newExpressionId)
        if newArgs == 0:
            with session.begin_transaction() as tx:
                # QUERY 11
                # get object used as first param for model.create call
                query=f"""
                    MATCH
                        (m)-[:PDG]->(v:VariableDeclarator)
                    WHERE
                        m.Id="{modelStmtId}" AND
                        v.Id="{newStmtId}"
                    RETURN *
                """
                queryResults = tx.run(query)
                for record in queryResults:
                    results.append({
                        "stmt": record["m"],
                        "variable_name": record["m"]["IdentifierName"]
                    })
        else:
            with session.begin_transaction() as tx:
                # QUERY 11
                # get object used as first param for model.create call
                query=f"""
                    MATCH
                        (d:VariableDeclarator)-[:PDG]->(v:VariableDeclarator)-[:AST]->(n:NewExpression)-[arg:AST]->(i:Identifier)
                    WHERE
                        n.Id="{newExpressionId}" AND
                        arg.RelationType="arg" AND
                        d.IdentifierName=i.IdentifierName
                    RETURN *
                """
                queryResults = tx.run(query)
                for record in queryResults:
                    results.append({
                        "stmt": record["d"],
                        "variable_name": record["i"]["IdentifierName"]
                    })

    else: # operationType == "SELECT"
        modelStmtId = modelAPICall["model_object"].id

        with session.begin_transaction() as tx:
            # QUERY 11
            # get object used as first param for model.create call
            query=f"""
                MATCH
                    (t)-[create:OBJECT]->(o:PDG_OBJECT)-[lookup:PDG]->(d:VariableDeclarator)-[:PDG]->(v:VariableDeclarator)-[init:AST]->(c:CallExpression)-[callee:AST]->(i:Identifier)
                WHERE
                    t.Id="{modelStmtId}" AND
                    create.RelationType="CREATE" AND
                    lookup.RelationType="LOOKUP" AND
                    lookup.IdentifierName="{modelOperation}" AND
                    c.Id="{callExpressionId}" AND
                    init.RelationType="init" AND
                    d.IdentifierName=i.IdentifierName
                RETURN *
            """
            queryResults = tx.run(query)
            for record in queryResults:
                results.append({
                    "stmt": record["v"],
                    "variable_name": record["v"]["IdentifierName"]
                })

    if len(results) > 0:
        return results[0]


def find_param_object(session, param):
    results = []
    stmtId = param["stmt"].id

    if not "variable_name" in param:
        return []

    variableName = param["variable_name"]
    # print(stmtId, variableName)
    with session.begin_transaction() as tx:
        # QUERY 11
        # get object used as first param for model.create call
        query=f"""
            MATCH
                (v)-[create:OBJECT]->(o:PDG_OBJECT)
            WHERE
                v.Id="{stmtId}" AND
                create.RelationType="CREATE" AND
                create.IdentifierName="{variableName}"
            RETURN *
        """
        queryResults = tx.run(query)
        for record in queryResults:
            results.append({
                "object": record["o"],
            })
    return results


def find_param_properties(session, paramObject):
    paramObjectId = paramObject.id
    hasMoreVersions = True
    properties = []

    # if the properties are in an ObjectExpression
    with session.begin_transaction() as tx:
            # QUERY 11
            # get writes to objects depedent of param
            query=f"""
                MATCH
                    (o1:PDG_OBJECT)<-[create:OBJECT]-(v)-[init:AST]-(oe:ObjectExpression)-[:AST]->(p:Property)-[key:AST]->(k:Identifier)
                WHERE
                    o1.Id="{paramObjectId}" AND
                    create.RelationType="CREATE" AND
                    key.RelationType="key"
                RETURN *
            """
            queryResults = tx.run(query)

            if queryResults.peek():
                for record in queryResults:
                    paramObjectId = record["o1"].id
                    properties.append(record["k"]["IdentifierName"])

    # If the properties are created by writes to object
    while hasMoreVersions:
        with session.begin_transaction() as tx:
            # QUERY 11
            # get writes to objects depedent of param
            query=f"""
                MATCH
                    (o1:PDG_OBJECT)-[new_version:OBJECT]->(o2)<-[write:PDG]-(stmt)
                WHERE
                    o1.Id="{paramObjectId}" AND
                    new_version.RelationType="NEW_VERSION" AND
                    write.RelationType="WRITE"
                RETURN *
            """
            queryResults = tx.run(query)

            if queryResults.peek():
                for record in queryResults:
                    paramObjectId = record["o2"].id
                    properties.append(record["write"]["IdentifierName"])
            else:
                hasMoreVersions = False

    return properties


#  "data_operations": [
#         { "operation": "POST /tickets/buy_ticket",
#           "data": [
#             { "table": "tickets", "column": "name" },
#             { "table": "tickets", "column": "e_mail" },
#             { "table": "tickets", "column": "destination" },
#             { "table": "tickets", "column": "date" },
#             { "table": "tickets", "column": "credit_card" }]
#         },
#         { "operation": "POST /newsletter/subscribe",
#           "data": [
#             { "table": "newsletter", "column": "e_mail" }]
#     }]

def dict_hash(dictionary: Dict[str, Any]) -> str:
    """MD5 hash of a dictionary."""
    dhash = hashlib.md5()
    # We need to sort arguments so {'a': 1, 'b': 2} is
    # the same as {'b': 2, 'a': 1}
    encoded = json.dumps(dictionary, sort_keys=True).encode()
    dhash.update(encoded)
    return dhash.hexdigest()


NEO4J_CONN_STRING="bolt://127.0.0.1:7687"
DEBUG=False
DEBUG2=False

dataOperations = []
hashCache = {}
paramCache = {}

neoDriver = GraphDatabase.driver(NEO4J_CONN_STRING, auth=('neo4j', 'admin'))
with neoDriver.session() as session:
    express = find_require_calls(session, "express")
    expressRouterCalls = find_express_router_methods(session, express)
    # for endpoint in expressRouterCalls:
    #     endpointName = endpoint["endpoint"]["param_value"]
    #     endpointType = endpoint["endpoint_type"]
    #     callbackDecl = endpoint["callback"]["callback_func"]
    #     print(f"{endpointType} {endpointName}")
    # if DEBUG:
    #     print(expressRouterCalls)

    mongoose = find_require_calls(session, "mongoose")
    mongooseModels = find_mongoose_model_calls(session, mongoose)

    if DEBUG2:
        print("# MongooseModels:", len(mongooseModels))
    for model in mongooseModels:
        schemaTable = model["param_value"]
        # print(model)
        # print(schemaTable)
        modelAPICalls = find_model_api_calls(session, model)

        if DEBUG2:
            print("# ModelAPICalls: ", len(modelAPICalls))

        for modelAPICall in modelAPICalls:
            modelExpression = modelAPICall["call"]
            modelOperation = modelAPICall["op"]
            # print(modelOperation)

            if DEBUG2:
                print("# ExpressRouterCalls:", len(expressRouterCalls))

            for endpoint in expressRouterCalls:
                endpointName = endpoint["endpoint"]["param_value"]
                endpointType = endpoint["endpoint_type"]
                callbackDecl = endpoint["callback"]["callback_func"]
                if DEBUG:
                    print(schemaTable, modelOperation, modelExpression.id, endpointType, endpointName)
                if is_call_in_function_scope(session, callbackDecl, modelAPICall["expression_stmt"]):
                    addedAllColumns = False
                    detectedObjs = []

                    param = find_api_param(session, modelAPICall)
                    if DEBUG:
                        print(modelAPICall["model_object"].id)
                        print("param:", param)

                    if param:
                        paramObject = find_param_object(session, param)

                        propertiesData = []
                        if len(paramObject) > 0:
                            paramObject = paramObject[0]["object"]
                            properties = find_param_properties(session, paramObject)

                            for prop in properties:
                                if DEBUG:
                                    print(f"Added ({prop}, {schemaTable}) for {endpointName} using {modelOperation}")

                                detectedObjs.append({
                                    "table": schemaTable,
                                    "column": prop
                                })


                            if len(properties) == 0:
                                if DEBUG:
                                    print(f"Added (*, {schemaTable}) for {endpointName} using {modelOperation}")
                                addedAllColumns = True
                                detectedObjs.append({
                                    "table": schemaTable,
                                    "column": "*"
                                })
                        else:
                            if DEBUG:
                                print(f"Added (unknown, {schemaTable}) for {endpointName} using {modelOperation}")
                            detectedObjs.append({
                                "table": schemaTable,
                                "column": "unknown",
                                "object": param["variable_name"]
                            })

                        if modelOperation in returnAllOperations and not addedAllColumns:
                            if DEBUG:
                                print(f"Added 2 (*, {schemaTable}) for {endpointName} using {modelOperation}")
                            detectedObjs.append({
                                    "table": schemaTable,
                                    "column": "*"
                                })


                        operation = f"{endpointType} {endpointName}"
                        if not endpointName in hashCache:
                            hashCache[operation] = []

                        if endpointType == "PARAM":
                            paramCache[operation] = detectedObjs
                        else:
                            for detectedObj in detectedObjs:
                                detectedHash = dict_hash(detectedObj)
                                if not detectedHash in hashCache[operation]:
                                    propertiesData.append(detectedObj)
                                    hashCache[operation].append(detectedHash)

                        if len(propertiesData) > 0:
                            dataOperations.append({
                                "operation": f"{endpointType} {endpointName}",
                                "data": propertiesData
                            })

        # print(json.dumps({"data_operations": dataOperations}, indent=4))


for paramData in paramCache.items():
    paramName = paramData[0].split(" ")[1]

    for op in dataOperations:
        operation = op["operation"]
        endpointName = operation.split(" ")[1]
        # if DEBUG:
        #     print(paramName, endpointName)

        if f":{paramName}" in endpointName:
            for detectedObj in paramData[1]:
                detectedHash = dict_hash(detectedObj)
                if not detectedHash in hashCache[operation]:
                    op["data"].append(detectedObj)
                    hashCache[operation].append(detectedHash)

## Process 
results = []
for operation in dataOperations:
    exists = False
    for result in results:
        if result['operation'] == operation['operation']:
            exists = True
            break
        # Append
    if exists == True:
        result['data'] = result['data'] + operation['data']
    else:
        # Create
        results.append(operation)

allDataQueries = []        
for result in results:
    for query in result['data']:
        if query['column'] == "*":
            allDataQueries.append({ "op": result['operation'], "table": query['table']})


resultsMerged = []
for result in results:
    dataColumns = []
    for query in result['data']:
        toRemove = False
        for toMerge in allDataQueries:
            if result['operation'] == toMerge['op'] and query['table'] == toMerge['table'] and not query['column'] == "*":
                toRemove = True
        if not toRemove:
            dataColumns.append(query)
    resultsMerged.append({ 'operation': result['operation'], 'data': dataColumns})

print(json.dumps({"data_operations": resultsMerged}, indent=4))



