import {
    DataCollectionRule,
    DataItemRule,
    DataLocationRule,
    DataMinimizationRule, 
    LawfulnessBaseRule,
    OperationEndpointRule,
    OperationPurposeRule,
    OperationRule,
    PersonalDataItemRule,
    PurposeRule
} from './Rules';
import { getDataProcessedByOperation, getDataProcessing, getPersonalDataOperations } from './Verifier';

export class Program {
    dataItems: DataItemRule[] = [];
    personalDataItems: PersonalDataItemRule[] = [];
    purposes: PurposeRule[] = [];
    dataCollection: DataCollectionRule[] = [];
    dataLocation: DataLocationRule[] = [];
    operations: OperationRule[] = [];
    operationPurpose: OperationPurposeRule[] = [];
    operationEndpoints: OperationEndpointRule[] = [];
    lawfulnessBases: LawfulnessBaseRule[] = [];


    generateRuntimeJson(): string {
        return JSON.stringify({
            "data_items": this.dataItems,
            "personal_data_items": this.personalDataItems,
            "purposes": this.purposes,
            "data_purposes": this.dataCollection,
            "data-location": this.dataLocation,
            "operations": this.operations,
            "operation_purposes": this.operationPurpose,
            "operation_endpoints": this.operationEndpoints,
            "lawfulness_bases": this.lawfulnessBases
        }, null, 3);
    }

    generateVerificationJson(): string {
        const data_processing = getDataProcessing(this.dataCollection, this.dataLocation)
        const operations = getPersonalDataOperations(this.operationPurpose, this.dataCollection, this.operationEndpoints)
        const data_operations = getDataProcessedByOperation(this.operationPurpose, this.dataCollection, this.operationEndpoints, this.dataLocation)
        return JSON.stringify({
            //"data_processing": data_processing,
            //"operations": operations,
            "data_operations": data_operations
        }, null, 3)
    }

}
