const bcrypt = require('bcryptjs');
const uuid = require('uuid');

module.exports = {
  generateRandomPassword() {
    const randomPassword = uuid.v4();
    const salt = bcrypt.genSaltSync(10);
    return bcrypt.hashSync(randomPassword, salt);
  }
};
