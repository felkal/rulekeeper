"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OutputWriter = void 0;
class OutputWriter {
}
exports.OutputWriter = OutputWriter;
//# sourceMappingURL=output_writer.js.map