"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clone = exports.printJSON = exports.resetObjectCount = exports.getNextObjectName = exports.resetVariableCount = exports.getNextVariableName = exports.resetNodeId = exports.getNextNodeId = exports.copyObj = void 0;
/* eslint-disable no-plusplus */
let VAR_COUNT = 1;
let NODE_COUNT = 1;
let OBJ_COUNT = 1;
function copyObj(obj) {
    const newObj = JSON.parse(JSON.stringify(obj));
    return newObj;
}
exports.copyObj = copyObj;
const getNextNodeId = () => NODE_COUNT++;
exports.getNextNodeId = getNextNodeId;
const resetNodeId = () => NODE_COUNT = 1;
exports.resetNodeId = resetNodeId;
const getNextVariableName = () => `v${VAR_COUNT++}`;
exports.getNextVariableName = getNextVariableName;
const resetVariableCount = () => VAR_COUNT = 1;
exports.resetVariableCount = resetVariableCount;
const getNextObjectName = () => `o${OBJ_COUNT++}`;
exports.getNextObjectName = getNextObjectName;
const resetObjectCount = () => OBJ_COUNT = 1;
exports.resetObjectCount = resetObjectCount;
const printJSON = (json) => console.log(JSON.stringify(json, null, 2));
exports.printJSON = printJSON;
function clone(a) {
    return JSON.parse(JSON.stringify(a));
}
exports.clone = clone;
//# sourceMappingURL=utils.js.map