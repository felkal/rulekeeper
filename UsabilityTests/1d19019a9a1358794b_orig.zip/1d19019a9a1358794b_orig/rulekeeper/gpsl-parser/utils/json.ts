export type output = { operation: String, data: Array<{table: String, column: String}>}

function hasSameData(staticAnalysisElement: output, manifestElement: output) {
    let result = false;
    let equal = true;
    if (staticAnalysisElement.operation == manifestElement.operation) {
        staticAnalysisElement.data.forEach(staticAnalysisColumn => {
            result = false; equal = false;
            manifestElement.data.forEach((manifestColumn: {table: String, column: String}) => { 
                if (manifestColumn.table === staticAnalysisColumn.table && manifestColumn.column == staticAnalysisColumn.column) equal = true;
            });
            if (equal) result = true;
        })
    } else result = true;
    return result;
}

export function diff(staticAnalysisObj: Array<output>, manifestObj: Array<output>) {
    let results: Set<String> = new Set<String>();
    staticAnalysisObj.forEach(staticAnalysisElement => { manifestObj.forEach(manifestElement => { if (!hasSameData(staticAnalysisElement, manifestElement)) results.add(staticAnalysisElement.operation)  })  });
    //manifestObj.forEach(e2 => { staticAnalysisObj.forEach(e1 => { if (!hasSameData(e1, e2)) results.add(e2.operation)  })  });
    return results;
}

export function processAnalysisFile(file: string, manifest: string) {
    const mapData = JSON.parse(manifest)['data-location'];
    const dataPerTable: { [key: string]: Array<string> } = {};
    mapData.forEach((data: {table: string, column: string, data: string}) => {
        if (dataPerTable[data.table]) dataPerTable[data.table].push(data.column)
        else dataPerTable[data.table] = [data.column]
    })
    let parsedAnalysis = JSON.parse(file)
    parsedAnalysis.data_operations.forEach((operation : {operation: string, data: Array<{table: string, column: string}>})=> {
        operation.data.forEach((data: {table: string, column: string}) => {
            if (data.column == "*") {
                let columns = dataPerTable[data.table]
                // Remove * column
                operation.data = operation.data.filter(function(item) {
                    return item.table != data.table && item.column && data.column
                });
                // Add all data column
                columns.forEach(column => {
                    operation.data.push({ table: data.table, column: column})
                })
            }
        });
    })
    return parsedAnalysis
}