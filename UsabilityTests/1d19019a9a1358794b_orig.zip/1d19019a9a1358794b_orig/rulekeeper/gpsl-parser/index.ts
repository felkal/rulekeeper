#!/usr/bin/env node
import * as fs from 'fs';
import { validateArgs, arguments } from "./utils/arguments";
import { diff, processAnalysisFile } from "./utils/json";
import parseProgram from "./parser/Parser";
import path from 'path';


const args: arguments = validateArgs()  // Validate program arguments

// Read file content
const fileContent = fs.readFileSync(`${args.input}`, 'utf8');

// Parse program
const program = parseProgram(fileContent);

// Generate parsed program json
const jsonParsedProgram = program.generateRuntimeJson();
fs.writeFileSync(`${path.dirname(args.input)}/gdpr-manifest.json`, jsonParsedProgram, 'utf8');

// Generate verifier json
const jsonVerifierProgram = program.generateVerificationJson();
fs.writeFileSync(`${path.dirname(args.input)}/gdpr-manifest-parsed.json`, jsonVerifierProgram, 'utf8');

// Read static analysis result
const analysisFileContent = fs.readFileSync(`${path.dirname(args.input)}/app-analysis-result.json`, 'utf8');
const analysisFileProcessed = processAnalysisFile(analysisFileContent, jsonParsedProgram)
fs.writeFileSync(`${path.dirname(args.input)}/app-analysis-result.json`, JSON.stringify(analysisFileProcessed, null, 4), 'utf8');
const outputDiff = diff(analysisFileProcessed.data_operations, JSON.parse(jsonVerifierProgram).data_operations, )
console.log("Difference:\n", outputDiff)