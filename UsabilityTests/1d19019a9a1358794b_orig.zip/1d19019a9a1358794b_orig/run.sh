#!/bin/bash

USE_CASE=$1

# Run queries
echo "[INFO] - Running python queries"
python3 rulekeeper/js-cpg/queries/rulekeeper.py > $USE_CASE/app-analysis-result.json
echo "[INFO] - Saved static analysis result in $USE_CASE/app-analysis-result.json"

# Run manifest parser
echo "[INFO] - Parsing the GDPR manifest file: $USE_CASE/gdpr_manifest.txt"
cd rulekeeper/gpsl-parser
echo "[INFO] - Saved gpsl parsing result in $USE_CASE/gdpr-manifest-parsed.json"
npm start -- -i ../../$USE_CASE/gdpr_manifest.txt
